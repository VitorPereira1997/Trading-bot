# Carteira Inteligente v16

Principais alterações:

- Persistência real da carteira e histórico de decisões através de Supabase.
- Carregamento automático da carteira ao abrir a app.
- Gravação automática ao adicionar posições, aceitar/rejeitar oportunidades ou importar CSV.
- Estado visível: **Ligado / Apenas sessão / Erro**.
- Botões para guardar e recarregar dados manualmente.
- Proteção opcional da app com `APP_PASSWORD` nos Secrets do Streamlit.
- Mantém exportação/importação CSV como cópia de segurança.

Consulta `CONFIGURAR_PERSISTENCIA.md` e executa `supabase_setup.sql` uma única vez.
