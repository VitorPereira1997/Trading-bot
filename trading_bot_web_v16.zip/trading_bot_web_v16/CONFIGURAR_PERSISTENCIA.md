# Versão 16 — guardar carteira permanentemente

A versão 16 continua a funcionar sem base de dados, mas nesse caso mostra **Apenas sessão** e os dados podem desaparecer quando o Streamlit reinicia.

## Antes de atualizar

Se a versão atual ainda mostra a tua carteira, abre **Carteira → Importar / exportar → Descarregar carteira CSV** e guarda esse ficheiro. Depois poderás importá-lo na versão 16.

## 1. Criar o armazenamento no Supabase

1. Cria um projeto no Supabase.
2. Abre o **SQL Editor**.
3. Copia e executa o conteúdo de `supabase_setup.sql`.
4. Copia o **Project URL** do teu projeto.
5. Cria/copia uma **Secret key** (`sb_secret_...`). Usa a chave secreta apenas no backend; não a coloques no GitHub.

## 2. Adicionar os Secrets no Streamlit

No Streamlit Community Cloud abre a tua app → **Settings → Secrets** e cola:

```toml
SUPABASE_URL = "https://SEU-PROJETO.supabase.co"
SUPABASE_SECRET_KEY = "sb_secret_..."
PORTFOLIO_OWNER_ID = "carteira-principal"
APP_PASSWORD = "escolhe-uma-palavra-passe-forte"
```

Guarda os Secrets e reinicia a app.

## 3. Confirmar

Abre **Carteira**. No topo deve aparecer:

**Dados permanentes: Ligado**

A partir desse momento, ao adicionar uma posição, aceitar/rejeitar uma oportunidade ou importar a carteira por CSV, a app grava automaticamente a carteira e o histórico no Supabase.

## Segurança

- Nunca coloques `SUPABASE_SECRET_KEY` ou `APP_PASSWORD` no GitHub.
- A Secret key tem privilégios elevados e deve ficar exclusivamente nos Secrets do Streamlit.
- `APP_PASSWORD` protege a interface da tua carteira quando a app está acessível pela internet.
