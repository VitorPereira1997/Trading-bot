-- Trading Bot / Carteira Inteligente - armazenamento permanente
-- Executar UMA VEZ no SQL Editor do projeto Supabase.

create table if not exists public.trading_bot_state (
    owner_id text primary key,
    state jsonb not null default '{}'::jsonb,
    updated_at timestamptz not null default now()
);

-- A carteira pessoal não deve ser acessível por chaves públicas.
alter table public.trading_bot_state enable row level security;
revoke all on table public.trading_bot_state from anon, authenticated;

-- A chave secreta usada apenas no backend Streamlit assume o role service_role.
grant usage on schema public to service_role;
grant select, insert, update, delete on table public.trading_bot_state to service_role;
